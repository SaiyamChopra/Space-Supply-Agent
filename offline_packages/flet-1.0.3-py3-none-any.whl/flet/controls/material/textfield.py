from dataclasses import dataclass
from enum import Enum
from typing import Annotated, Optional, Union

from flet.controls.adaptive_control import AdaptiveControl
from flet.controls.base_control import BaseControl, control, value
from flet.controls.control_event import ControlEventHandler, Event, EventHandler
from flet.controls.core.autofill_group import AutofillHint
from flet.controls.core.text import TextSelection, TextSelectionChangeEvent
from flet.controls.material.form_field_control import FormFieldControl
from flet.controls.padding import PaddingValue
from flet.controls.text_style import StrutStyle
from flet.controls.types import (
    Brightness,
    ClipBehavior,
    ColorValue,
    MouseCursor,
    Number,
    TextAlign,
)
from flet.utils.validation import V

__all__ = [
    "InputFilter",
    "KeyboardType",
    "NumbersOnlyInputFilter",
    "PastedFile",
    "TextCapitalization",
    "TextField",
    "TextFieldPasteFilesEvent",
    "TextOnlyInputFilter",
]


@dataclass
class PastedFile:
    """
    A file pasted into a :class:`~flet.TextField`.
    """

    name: str
    """
    File name, e.g. `"image.png"`. A pasted screenshot gets a generic name.
    """

    mime_type: str
    """
    MIME type reported by the platform, e.g. `"image/png"`; can be empty.
    """

    bytes: bytes
    """
    File contents.
    """


@dataclass
class TextFieldPasteFilesEvent(Event["TextField"]):
    """
    Event emitted when files are pasted into a :class:`~flet.TextField`.
    """

    files: list[PastedFile]
    """
    The pasted files.
    """


class KeyboardType(Enum):
    """
    The type of information for which to optimize the text input control.

    On Android, behavior may vary across device and keyboard provider.
    """

    NONE = "none"
    """
    Prevents the OS from showing the on-screen virtual keyboard.
    """

    TEXT = "text"
    """
    Optimized for textual information.

    Requests the default platform keyboard.
    """

    MULTILINE = "multiline"
    """
    Optimized for multiline textual information.

    Requests the default platform keyboard, but accepts newlines when the
    enter key is pressed. This is the input type used for all multiline text
    fields.
    """

    NUMBER = "number"
    """
    Optimized for unsigned numerical information without a decimal point.

    Requests a default keyboard with ready access to the number keys.
    """

    PHONE = "phone"
    """
    Optimized for telephone numbers.

    Requests a keyboard with ready access to the number keys, `"*"`, and `"#"`.
    """

    DATETIME = "datetime"
    """
    Optimized for date and time information.

    - On iOS, requests the default keyboard.
    - On Android, requests a keyboard with ready
        access to the number keys, `":"`, and `"-"`.
    """

    EMAIL = "email"
    """
    Optimized for email addresses.

    Requests a keyboard with ready access to the `"@"` and `"."` keys.
    """

    URL = "url"
    """
    Optimized for URLs.

    Requests a keyboard with ready access to the `"/"` and `"."` keys.
    """

    VISIBLE_PASSWORD = "visiblePassword"
    """
    Optimized for passwords that are visible to the user.

    Requests a keyboard with ready access to both letters and numbers.
    """

    NAME = "name"
    """
    Optimized for a person's name.

    - On iOS, requests the [UIKeyboardType.namePhonePad](https://developer.apple.com/documentation/uikit/uikeyboardtype/namephonepad)
        keyboard, a keyboard optimized for entering a person’s name or phone number.
        Does not support auto-capitalization.
    - On Android, requests a keyboard optimized for
        [TYPE_TEXT_VARIATION_PERSON_NAME](https://developer.android.com/reference/android/text/InputType#TYPE_TEXT_VARIATION_PERSON_NAME).
    """  # noqa: E501

    STREET_ADDRESS = "streetAddress"
    """
    Optimized for postal mailing addresses.

    - On iOS, requests the default keyboard.
    - On Android, requests a keyboard optimized for
        [TYPE_TEXT_VARIATION_POSTAL_ADDRESS](https://developer.android.com/reference/android/text/InputType#TYPE_TEXT_VARIATION_POSTAL_ADDRESS).
    """  # noqa: E501

    WEB_SEARCH = "webSearch"
    """
    Optimized for web searches.

    Requests a keyboard that includes keys useful for web searches as well as URLs.

    - On iOS, requests a default keyboard with ready access to the `"."` key.
        In contrast to :attr:`URL`, a space bar is available.
    - On Android this is remapped to the :attr:`URL` keyboard type as it always
        shows a space bar.
    """

    TWITTER = "twitter"
    """
    Optimized for social media.

    Requests a keyboard that includes keys useful for handles and tags.

    - On iOS, requests a default keyboard with ready access to the `"@"` and `"#"` keys.
    - On Android this is remapped to the :attr:`EMAIL` keyboard type as it
        always shows the `"@"` key.
    """


class TextCapitalization(Enum):
    """
    Configures how the platform keyboard will select an uppercase or lowercase \
    keyboard.

    Only supports text keyboards, other keyboard types will ignore this
    configuration. Capitalization is locale-aware.
    """

    CHARACTERS = "characters"
    """
    Uppercase keyboard for each character.

    Info:
        Corresponds to `InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS` on Android, and
        `UITextAutocapitalizationTypeAllCharacters` on iOS.
    """

    WORDS = "words"
    """
    Uppercase keyboard for the first letter of each word.

    Info:
        Corresponds to `InputType.TYPE_TEXT_FLAG_CAP_WORDS` on Android, and
        `UITextAutocapitalizationTypeWords` on iOS.
    """

    SENTENCES = "sentences"
    """
    Uppercase keyboard for the first letter of each sentence.

    Info:
        Corresponds to `InputType.TYPE_TEXT_FLAG_CAP_SENTENCES` on Android, and
        `UITextAutocapitalizationTypeSentences` on iOS.
    """

    NONE = "none"
    """
    Lowercase keyboard.
    """


@value
class InputFilter:
    """
    An input filter that uses a regular expression to allow or deny/block certain \
    patterns in the input.
    """

    regex_string: str
    """
    A regular expression pattern for the filter.

    It is recommended to use raw strings (prefix your string with `r`) for the pattern,
    ex: `r"pattern"`.
    """

    allow: bool = True
    """
    A boolean value indicating whether to allow or deny/block the matched patterns.
    """

    replacement_string: str = ""
    """
    A string used to replace banned/denied patterns.
    """

    multiline: bool = False
    """
    Whether this regular expression matches multiple lines.

    If the regexp does match multiple lines, the `"^"` and `"$"` characters match the
    beginning and end of lines. If not, the characters match the beginning and end of
    the input.
    """

    case_sensitive: bool = True
    """
    Whether this regular expression is case sensitive.

    If the regular expression is not case sensitive, it will match an input letter with
    a pattern letter even if the two letters are different case versions of the same
    letter.
    """

    unicode: bool = False
    """
    Whether this regular expression uses Unicode mode.
    """

    dot_all: bool = False
    """
    Whether `"."` in this regular expression matches line terminators.

    When false, the `"."` character matches a single character, unless that character
    terminates a line. When true, then the `"."` character will match any single
    character including line terminators.

    This feature is distinct from `multiline`. They affect the behavior of different
    pattern characters, so they can be used together or separately.
    """


class NumbersOnlyInputFilter(InputFilter):
    """
    Allows only numbers.
    """

    def __init__(self):
        super().__init__(regex_string=r"^[0-9]*$", allow=True, replacement_string="")


class TextOnlyInputFilter(InputFilter):
    """
    Allows only text.
    """

    def __init__(self):
        super().__init__(regex_string=r"^[a-zA-Z]*$", allow=True, replacement_string="")


@control(
    "TextField", categories=("input", "form"), tags=("text", "editable", "validation")
)
class TextField(FormFieldControl, AdaptiveControl):
    """
    A text field lets the user enter text, either with hardware keyboard or with an \
    onscreen keyboard.

    Example:
    ```python
    ft.TextField(label="Name", hint_text="Jane Doe")
    ```
    """

    value: str = ""
    """
    Current value of this text field.
    """

    selection: Optional[TextSelection] = None
    """
    Represents the current text selection or caret position in the field.

    When the user selects text, this property is updated to reflect the selected range.
    If no text is selected, it contains an empty range indicating the caret position.

    Setting this property visually updates the field's selection to match the given
    value, and hence leads to the :attr:`on_selection_change` event being triggered.
    To ensure the selection is visible and the event is fired, the text field must
    be focused. Call :meth:`flet.FormFieldControl.focus`
    on the field before setting this property.
    """

    keyboard_type: KeyboardType = KeyboardType.TEXT
    """
    The type of keyboard to use for editing the text.
    """

    multiline: bool = False
    """
    Whether this field can contain multiple lines of text.
    """

    min_lines: Annotated[
        Optional[int],
        V.gt(0),
        V.le_field("max_lines"),
    ] = None
    """
    The minimum number of lines to occupy when the content spans fewer lines.

    This affects the height of the field itself and does not limit the number of lines
    that can be entered into the field.

    Defaults to `1`.

    Raises:
        ValueError: If it is not strictly greater than `0`.
        ValueError: If it is not less than or equal to :attr:`max_lines` when both
            are set.
    """

    max_lines: Annotated[
        Optional[int],
        V.gt(0),
        V.ge_field("min_lines"),
    ] = None
    """
    The maximum number of lines to show at one time, wrapping if necessary.

    This affects the height of the field itself and does not limit the number of lines
    that can be entered into the field.

    If this is `1` (the default), the text will not wrap, but will scroll horizontally
    instead.

    Raises:
        ValueError: If it is not strictly greater than `0`.
        ValueError: If it is not greater than or equal to :attr:`min_lines` when
            both are set.
    """

    max_length: Annotated[
        Optional[int],
        V.or_(
            V.gt(0),
            V.eq(-1),
            message="max_length must be either strictly greater than 0 or equal to -1",
        ),
    ] = None
    """
    Limits a maximum number of characters that can be entered into TextField.

    Raises:
        ValueError: If it is not strictly greater than `0` or equal to `-1`.
    """

    password: bool = False
    """
    Whether to hide the text being edited.
    """

    can_reveal_password: bool = False
    """
    Displays a toggle icon button that allows revealing the entered password. Is shown \
    if both :attr:`password` and `can_reveal_password` are `True`.

    The icon is displayed in the same location as :attr:`flet.FormFieldControl.suffix`
    and in case both `can_reveal_password`/:attr:`password` and `suffix` are
    provided, then the :attr:`flet.FormFieldControl.suffix` won't be shown.
    """

    read_only: bool = False
    """
    Whether the text can be changed.

    When this is set to `True`, the text cannot be modified by any shortcut or keyboard
    operation. The text is still selectable.
    """

    shift_enter: bool = False
    """
    Changes the behavior of `Enter` button in :attr:`multiline` textfield to be \
    chat-like, i.e. new line can be added with `Shift`+`Enter` and pressing just \
    `Enter` fires :attr:`on_submit` event.
    """

    ignore_up_down_keys: bool = False
    """
    Whether to intercept Arrow-Up and Arrow-Down when this field has focus.

    When set to `True`, pressing those keys does not move the caret to the beginning
    or end of the text respectively.
    """

    text_align: Optional[TextAlign] = None
    """
    How the text should be aligned horizontally.

    Defaults to :attr:`flet.TextAlign.LEFT`.
    """

    autofocus: bool = False
    """
    True if the control will be selected as the initial focus. If there is more than \
    one control on a page with autofocus set, then the first one added to the page \
    will get focus.
    """

    capitalization: Optional[TextCapitalization] = None
    """
    Enables automatic on-the-fly capitalization of entered text.

    Defaults to :attr:`flet.TextCapitalization.NONE`.
    """

    autocorrect: bool = True
    """
    Whether to enable autocorrection.
    """

    enable_suggestions: bool = True
    """
    Whether to show input suggestions as the user types.

    This flag only affects Android. On iOS, suggestions are tied directly to
    `autocorrect`, so that suggestions are only shown when `autocorrect` is `True`.
    On Android autocorrection and suggestion are controlled separately.
    """

    smart_dashes_type: bool = True
    """
    Whether to allow the platform to automatically format dashes.

    This flag only affects iOS versions 11 and above. As an example of what this does,
    two consecutive hyphen characters will be automatically replaced with one en dash,
    and three consecutive hyphens will become one em dash.
    """

    smart_quotes_type: bool = True
    """
    Whether to allow the platform to automatically format quotes.

    This flag only affects iOS. As an example of what this does, a standard vertical
    double quote character will be automatically replaced by a left or right double
    quote depending on its position in a word.
    """

    show_cursor: bool = True
    """
    Whether the field's cursor is to be shown.
    """

    cursor_color: Optional[ColorValue] = None
    """
    The color of TextField cursor.
    """

    cursor_error_color: Optional[ColorValue] = None
    """
    The color of the text cursor while the field is showing an error.

    If not set, the cursor color falls back to the error text style and then to the
    theme's error color.
    """

    cursor_width: Number = 2.0
    """
    Sets cursor width.
    """

    cursor_height: Optional[Number] = None
    """
    Sets cursor height.
    """

    cursor_radius: Optional[Number] = None
    """
    Sets cursor radius.
    """

    selection_color: Optional[ColorValue] = None
    """
    The color of TextField selection.
    """

    input_filter: Optional[InputFilter] = None
    """
    Provides as-you-type filtering/validation.

    Similar to the :attr:`on_change` callback, the input filters are not applied
    when the content of the field is changed programmatically.
    """

    obscuring_character: str = "•"
    """
    The single character used to mask the text when :attr:`password` is `True`.
    """

    enable_interactive_selection: bool = True
    """
    Whether interactive text selection is enabled.

    When enabled, users can move the caret, select text, and use the cut/copy/paste
    menu. When disabled, selection cannot be adjusted interactively and editing
    shortcuts for cut/copy/paste are suppressed.
    """

    enable_ime_personalized_learning: bool = True
    """
    Whether the input method is allowed to learn from what the user types.

    This affects Android only and controls personalized data such as typing history
    and user dictionary entries.
    """

    can_request_focus: bool = True
    """
    Whether this field can request focus.

    If set to `False`, the field does not request focus when tapped or when its
    context menu is shown, and it cannot be reached with keyboard focus traversal.
    """

    ignore_pointers: bool = False
    """
    Whether this field ignores pointer events.
    """

    enable_stylus_handwriting: bool = True
    """
    Whether this field supports stylus handwriting input.

    On supported devices, the user can write directly on top of the field with a
    stylus instead of typing from the keyboard.
    """

    animate_cursor_opacity: Optional[bool] = None
    """
    Whether the text cursor animates between transparent and opaque during each blink.

    If not set, the default follows the platform behavior used by Flet.
    """

    always_call_on_tap: bool = False
    """
    Whether :attr:`on_click` should be called for every tap.

    By default, only the first tap in a tap sequence triggers :attr:`on_click`.
    When enabled, consecutive taps trigger it as well.
    """

    scroll_padding: PaddingValue = 20
    """
    Padding to keep around the field when a surrounding scrollable scrolls it into view.

    When the field receives focus and is partly hidden, for example by the onscreen
    keyboard, this padding helps keep space between the field and the edges of the
    surrounding scrollable after scrolling.
    """

    clip_behavior: ClipBehavior = ClipBehavior.HARD_EDGE
    """
    How the field's contents should be clipped.

    See :class:`~flet.ClipBehavior` for the available clipping modes.
    """

    keyboard_brightness: Optional[Brightness] = None
    """
    The brightness to use for the onscreen keyboard.

    This setting is honored on iOS only.
    """

    mouse_cursor: Optional[MouseCursor] = None
    """
    The mouse pointer to show while hovering over the field.

    If not set, the standard text cursor is used.
    """

    strut_style: Optional[StrutStyle] = None
    """
    The :class:`~flet.StrutStyle` used for vertical text layout.

    Strut style establishes a predictable minimum line height, which is useful when
    entered text may vary in font metrics or script.
    """

    autofill_hints: Optional[Union[AutofillHint, list[AutofillHint]]] = None
    """
    Helps the autofill service identify the type of this text input.

    More information
    [here](https://api.flutter.dev/flutter/material/TextField/autofillHints.html).
    """

    on_change: Optional[ControlEventHandler["TextField"]] = None
    """
    Called when the typed input for the TextField has changed.
    """

    on_selection_change: Optional[
        EventHandler[TextSelectionChangeEvent["TextField"]]
    ] = None
    """
    Called when the text selection or caret position changes.

    This can be triggered either by user interaction (selecting text or moving
    the caret) or programmatically (through the :attr:`selection` property).
    """

    on_paste_files: Optional[EventHandler[TextFieldPasteFilesEvent]] = None
    """
    Called when the user pastes files into the field, such as a screenshot or
    an image copied from a web page or the OS file manager.

    - Web: works in every browser, with no clipboard permission prompt. A
      paste that carries files doesn't also insert text into the field.
    - Desktop: `Ctrl`/`Cmd`+`V` reports an image on the clipboard; text is
      pasted as usual.

    Useful for attaching images to a chat message. Only the focused field
    receives pasted files.
    """

    on_click: Optional[ControlEventHandler["TextField"]] = None
    """
    Called when the field is tapped.

    If :attr:`always_call_on_tap` is `True`, this event is also triggered for
    consecutive taps.
    """

    on_submit: Optional[ControlEventHandler["TextField"]] = None
    """
    Called when user presses ENTER while focus is on TextField.
    """

    on_focus: Optional[ControlEventHandler["TextField"]] = None
    """
    Called when the control has received focus.
    """

    on_blur: Optional[ControlEventHandler["TextField"]] = None
    """
    Called when the control has lost focus.
    """

    on_tap_outside: Optional[ControlEventHandler["TextField"]] = None
    """
    Called when a pointer-down event occurs outside the field while it is focused.

    Use this to react when the user taps away from the field.

    Note:
        This callback is a notification only and does not include the pointer event
        details.
    """

    def _migrate_state(self, other: BaseControl):
        super()._migrate_state(other)
        if (
            isinstance(other, TextField)
            and self.value is None
            and self.value != other.value
        ):
            self.value = other.value

    def before_update(self):
        super().before_update()
        if (
            self.bgcolor is not None
            or self.fill_color is not None
            or self.hover_color is not None
            or self.focused_color is not None
        ) and self.filled is None:
            self.filled = True  # required to display any of the above colors
